#!/bin/bash
echo "Starting GoLogin Automation App..."
node server.js