# GoLogin Automation App

## Setup Instructions

1. Create a `.env.local` file with your credentials:
NEXT_PUBLIC_SUPABASE_URL=https://umhdnhckxgqywxgpybgo.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtaGRuaGNreGdxeXd4Z3B5YmdvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk0MDA1NzYsImV4cCI6MjA3NDk3NjU3Nn0.sodO3ZUaTWDxBBZitsrc_j3SUmVWBNlAsQoDAdzs8mI
GOLOGIN_API_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2OGQ2NTY0MDY5MjAxM2U4NTdjNzhiNWYiLCJ0eXBlIjoiZGV2Iiwiand0aWQiOiI2OGUzOWZmMzA5MjQ3MDlkYTk4MjBkZGUifQ.jlx5HAx3JMyTMn402FUucpwDnryzP_M1hEnoXRCec6w

2. Run the app:
- **Windows**: Double-click `start.bat`
- **Mac/Linux**: Run `./start.sh` in terminal

3. Open http://localhost:3000 in your browser

## Requirements
- GoLogin Desktop App installed